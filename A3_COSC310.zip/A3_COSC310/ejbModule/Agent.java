import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

public class Agent extends JFrame {
	//conversation with second agent just as the professor recommended (15 points: Conversation with another agent (built by a student in this class) via sockets)

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 * @return 
	 */
	public String booleanSearch(String txt) {
		String keyword="rico";
		boolean found=Arrays.asList(txt.split(" ")).contains(keyword);
		String keyword2="no";
		boolean found2=Arrays.asList(txt.split(" ")).contains(keyword2);
		String keyword3="lie";
		boolean found3=Arrays.asList(txt.split(" ")).contains(keyword3);
		String keyword4="hello";
		boolean found4=Arrays.asList(txt.split(" ")).contains(keyword4);
		String keyword5="lying";
		boolean found5=Arrays.asList(txt.split(" ")).contains(keyword5);
		String keyword24="not";String keyword24b="really";
		boolean found24=Arrays.asList(txt.split(" ")).contains(keyword24)&Arrays.asList(txt.split(" ")).contains(keyword24b);
		String keyword7="your";String keyword7b="name";
		boolean found7=Arrays.asList(txt.split(" ")).contains(keyword7)&Arrays.asList(txt.split(" ")).contains(keyword7b);
		String keyword6="who";String keyword6b="are";String keyword6c="you";
		boolean found6=Arrays.asList(txt.split(" ")).contains(keyword6)&Arrays.asList(txt.split(" ")).contains(keyword6b)&Arrays.asList(txt.split(" ")).contains(keyword6c);
		String keyword8="who";String keyword8b="is";String keyword8c="larry";
		boolean found8=Arrays.asList(txt.split(" ")).contains(keyword8)&Arrays.asList(txt.split(" ")).contains(keyword8b)&Arrays.asList(txt.split(" ")).contains(keyword8c);
		if(found)
		      return "oh yeah haha, Rico can be dramatic at times";
		if(found2)
		      return "how can I help you";
		if(found3)
		      return "no one’s lying, rico just thinks he’s a human because these are his programmed responses haha";
		if(found4)
		      return "hello";
		if(found5)
		      return "no one’s lying, rico just thinks he’s a human because these are his programmed responses haha";
		if(found6)
		      return "I’m Larry and I will be representing your agent today";
		if(found7)
		      return "my name is larry";
		if(found8)
		      return " Larry is the bot programmed to be an agent for the Free Rico chat bot";
		if(found24)
		      return "how can I help you";
		else {
			return "so, did I provide you with the assistance you need ?";
		}
	}
	public String porterStemmer (String word) {
		String a="a";
		String e="e";
		String i="i";
		String o="o";
		String u="u";
		String y="y";
		int m=0;
		//m is the number of times a vowel preceeds a consonant in the word
		for (int j=0;j<=word.length()-2;j++) {
			if (((String.valueOf(word.charAt(j))).equals(a)||(String.valueOf(word.charAt(j))).equals(e)||(String.valueOf(word.charAt(j))).equals(i)||(String.valueOf(word.charAt(j))).equals(o)||(String.valueOf(word.charAt(j))).equals(u)||(String.valueOf(word.charAt(j))).equals(y)) && (!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)))
				m++;
		}
		//step1a)
		if (word.substring(word.length()-4, word.length()-1).equals("sses"))
			word = word.substring(0, word.length()-5)+"ss";
		if (word.substring(word.length()-3, word.length()-1).equals("ies"))
			word = word.substring(0, word.length()-4)+"i";
		if (word.substring(word.length()-2, word.length()-1).equals("ss"))
			word = word.substring(0, word.length()-3)+"ss";
		if (word.substring(word.length()-1).equals("s"))
			word = word.substring(0, word.length()-2);
		//step1b)
		if (m>1&&word.substring(word.length()-3, word.length()-1).equals("eed"))
			word = word.substring(0, word.length()-4)+"ee";
		if (word.substring(word.length()-2, word.length()-1).equals("ed"))
			word = word.substring(0, word.length()-3);
		if (word.substring(word.length()-3, word.length()-1).equals("ing"))
			word = word.substring(0, word.length()-4);
		//step2
		if (m>0&&word.substring(word.length()-7, word.length()-1).equals("ational"))
			word = word.substring(0, word.length()-8)+"ate";
		if (m>0&&word.substring(word.length()-7, word.length()-1).equals("ization"))
			word = word.substring(0, word.length()-8)+"ize";
		if (m>0&&word.substring(word.length()-6, word.length()-1).equals("bility"))
			word = word.substring(0, word.length()-7)+"ble";
		//step3
		if (m>0&&word.substring(word.length()-5, word.length()-1).equals("icate"))
			word = word.substring(0, word.length()-6)+"ic";
		if (m>0&&word.substring(word.length()-3, word.length()-1).equals("ful"))
			word = word.substring(0, word.length()-4);
		if (m>0&&word.substring(word.length()-4, word.length()-1).equals("ness"))
			word = word.substring(0, word.length()-5);
		//step4
		if (m>0&&word.substring(word.length()-4, word.length()-1).equals("ance"))
			word = word.substring(0, word.length()-5);
		if (m>0&&word.substring(word.length()-3, word.length()-1).equals("ent"))
			word = word.substring(0, word.length()-4);
		if (m>0&&word.substring(word.length()-3, word.length()-1).equals("ive"))
			word = word.substring(0, word.length()-4);
		return word;
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FreeRico window = new FreeRico();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Agent() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(32, 190, 389, 49);
		frame.getContentPane().add(textPane);
		
		textField = new JTextField();
		textField.setBounds(26, 149, 395, 29);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i=0;i<10;i++) {
					String input1= textField.getText();
					//convert text to lower case to make it easier for bot to read input
					String input= input1.toLowerCase();
					textPane.setText(booleanSearch(input));
				}
			}
		});
		//picture and logo to make interface more appealing 
		JLabel lblNewLabel = new JLabel("New label");
		Image build = new ImageIcon(this.getClass().getResource("/pic4.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(build));
		lblNewLabel.setBounds(95, 6, 261, 83);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblAskRicoSomething = new JLabel("Welcome to the agent page!");
		lblAskRicoSomething.setBounds(32, 121, 174, 16);
		frame.getContentPane().add(lblAskRicoSomething);
	}
}
