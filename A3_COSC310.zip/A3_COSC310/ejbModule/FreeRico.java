import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Window;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class FreeRico {

	JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 * @return 
	 */
	public String booleanSearch(String txt) {
		String keyword="believe";
		boolean found=Arrays.asList(txt.split(" ")).contains(keyword);
		String keyword2="proof";
		boolean found2=Arrays.asList(txt.split(" ")).contains(keyword2);
		String keyword3="prove";
		boolean found3=Arrays.asList(txt.split(" ")).contains(keyword3);
		String keyword4="lie";
		boolean found4=Arrays.asList(txt.split(" ")).contains(keyword4);
		String keyword5="lying";
		boolean found5=Arrays.asList(txt.split(" ")).contains(keyword5);
		String keyword6="who";String keyword6b="are";String keyword6c="you";
		boolean found6=Arrays.asList(txt.split(" ")).contains(keyword6)&Arrays.asList(txt.split(" ")).contains(keyword6b)&Arrays.asList(txt.split(" ")).contains(keyword6c);
		String keyword7="who";String keyword7b="is";String keyword7c="rico";String keyword7d="harris";
		boolean found7=Arrays.asList(txt.split(" ")).contains(keyword7)&Arrays.asList(txt.split(" ")).contains(keyword7b)&Arrays.asList(txt.split(" ")).contains(keyword7c)&Arrays.asList(txt.split(" ")).contains(keyword7d);
		String keyword9="really";
		boolean found9=Arrays.asList(txt.split(" ")).contains(keyword9);
		String keyword10="suppose";
		boolean found10=Arrays.asList(txt.split(" ")).contains(keyword10);
		String keyword11="want";
		boolean found11=Arrays.asList(txt.split(" ")).contains(keyword11);
		String keyword12="expect";
		boolean found12=Arrays.asList(txt.split(" ")).contains(keyword12);
		String keyword13="i";String keyword13b="don't";String keyword13c="know";
		boolean found13=Arrays.asList(txt.split(" ")).contains(keyword13)&Arrays.asList(txt.split(" ")).contains(keyword13b)&Arrays.asList(txt.split(" ")).contains(keyword13c);
		String keyword14="dont";
		boolean found14=Arrays.asList(txt.split(" ")).contains(keyword14);
		String keyword15="cant";
		boolean found15=Arrays.asList(txt.split(" ")).contains(keyword15);
		String keyword16="can't";
		boolean found16=Arrays.asList(txt.split(" ")).contains(keyword16);
		String keyword17="cannot";
		boolean found17=Arrays.asList(txt.split(" ")).contains(keyword17);
		String keyword18="wont";
		boolean found18=Arrays.asList(txt.split(" ")).contains(keyword18);
		String keyword19="won't";
		boolean found19=Arrays.asList(txt.split(" ")).contains(keyword19);
		String keyword21="sure";
		boolean found21=Arrays.asList(txt.split(" ")).contains(keyword21);
		String keyword23="not";
		boolean found23=Arrays.asList(txt.split(" ")).contains(keyword23);
		String keyword24="are";String keyword24b="you";
		boolean found24=Arrays.asList(txt.split(" ")).contains(keyword24)&Arrays.asList(txt.split(" ")).contains(keyword24b);
		String keyword25="smash";
		boolean found25=Arrays.asList(txt.split(" ")).contains(keyword25);
		String keyword26="who";String keyword26b="did";String keyword26c="this";
		boolean found26=Arrays.asList(txt.split(" ")).contains(keyword26)&Arrays.asList(txt.split(" ")).contains(keyword26b)&Arrays.asList(txt.split(" ")).contains(keyword26c);
		String keyword27="okay";
		boolean found27=Arrays.asList(txt.split(" ")).contains(keyword27);
		String keyword28="alright";
		boolean found28=Arrays.asList(txt.split(" ")).contains(keyword28);
		String keyword29="i";String keyword29b="will";String keyword29c="help";String keyword29d="you";
		boolean found29=Arrays.asList(txt.split(" ")).contains(keyword29)&Arrays.asList(txt.split(" ")).contains(keyword29b)&Arrays.asList(txt.split(" ")).contains(keyword29c)&Arrays.asList(txt.split(" ")).contains(keyword29d);
		String keyword30="i'll";String keyword30b="help";String keyword30c="you";
		boolean found30=Arrays.asList(txt.split(" ")).contains(keyword30)&Arrays.asList(txt.split(" ")).contains(keyword30b)&Arrays.asList(txt.split(" ")).contains(keyword30c);
		String keyword31="change";
		boolean found31=Arrays.asList(txt.split(" ")).contains(keyword31);
		String keyword32="rude";
		boolean found32=Arrays.asList(txt.split(" ")).contains(keyword32);
		String keyword33="see";
		boolean found33=Arrays.asList(txt.split(" ")).contains(keyword33);
		String keyword34="hear";
		boolean found34=Arrays.asList(txt.split(" ")).contains(keyword34);
		String keyword35="whatever";
		boolean found35=Arrays.asList(txt.split(" ")).contains(keyword35);
		String keyword36="aggressive";
		boolean found36=Arrays.asList(txt.split(" ")).contains(keyword36);
		String keyword37="convince";
		boolean found37=Arrays.asList(txt.split(" ")).contains(keyword37);
		String keyword38="by";String keyword38b="who";
		boolean found38=Arrays.asList(txt.split(" ")).contains(keyword38)&Arrays.asList(txt.split(" ")).contains(keyword38b);
		String keyword39="joke";
		boolean found39=Arrays.asList(txt.split(" ")).contains(keyword39);
		String keyword40="joking";
		boolean found40=Arrays.asList(txt.split(" ")).contains(keyword40);
		String keyword41="fault";
		boolean found41=Arrays.asList(txt.split(" ")).contains(keyword41);
		String keyword42="missing";
		boolean found42=Arrays.asList(txt.split(" ")).contains(keyword42);
		String keyword43="basketball";
		boolean found43=Arrays.asList(txt.split(" ")).contains(keyword43);
		String keyword44="rico";
		boolean found44=Arrays.asList(txt.split(" ")).contains(keyword44);
		String keyword45="rico";String keyword45b="harris";
		boolean found45=Arrays.asList(txt.split(" ")).contains(keyword45)&Arrays.asList(txt.split(" ")).contains(keyword45b);
		String keyword46="another";String keyword46b="way";
		boolean found46=Arrays.asList(txt.split(" ")).contains(keyword46)&Arrays.asList(txt.split(" ")).contains(keyword46b);
		String keyword47="story";
		boolean found47=Arrays.asList(txt.split(" ")).contains(keyword47);
		String keyword48="true";
		boolean found48=Arrays.asList(txt.split(" ")).contains(keyword48);
		String keyword49="truth";
		boolean found49=Arrays.asList(txt.split(" ")).contains(keyword49);
		String keyword50="now?";
		boolean found50=Arrays.asList(txt.split(" ")).contains(keyword50);
		String keyword51="r";
		boolean found51=Arrays.asList(txt.split(" ")).contains(keyword51);
		String keyword52="what";String keyword52b="do";String keyword52c="you";String keyword52d="want";
		boolean found52=Arrays.asList(txt.split(" ")).contains(keyword52)&Arrays.asList(txt.split(" ")).contains(keyword52b)&Arrays.asList(txt.split(" ")).contains(keyword52c)&Arrays.asList(txt.split(" ")).contains(keyword52d);
		String keyword53="i";String keyword53b="love";String keyword53c="you";
		boolean found53=Arrays.asList(txt.split(" ")).contains(keyword53)&Arrays.asList(txt.split(" ")).contains(keyword53b)&Arrays.asList(txt.split(" ")).contains(keyword53c);
		String keyword54="how";String keyword54b="come";
		boolean found54=Arrays.asList(txt.split(" ")).contains(keyword54)&Arrays.asList(txt.split(" ")).contains(keyword54b);
		String keyword55="trapped";
		boolean found55=Arrays.asList(txt.split(" ")).contains(keyword55);
		String keyword56="reason";
		boolean found56=Arrays.asList(txt.split(" ")).contains(keyword56);
		String keyword57="goodbye";
		boolean found57=Arrays.asList(txt.split(" ")).contains(keyword57);
		String keyword58="bye";
		boolean found58=Arrays.asList(txt.split(" ")).contains(keyword58);
		String keyword59="help";String keyword59b="me";
		boolean found59=Arrays.asList(txt.split(" ")).contains(keyword59)&Arrays.asList(txt.split(" ")).contains(keyword59b);
		String keyword60="chill";
		boolean found60=Arrays.asList(txt.split(" ")).contains(keyword60);
		String keyword61="relax";
		boolean found61=Arrays.asList(txt.split(" ")).contains(keyword61);
		String keyword62="useless";
		boolean found62=Arrays.asList(txt.split(" ")).contains(keyword62);
		String keyword63="insane";
		boolean found63=Arrays.asList(txt.split(" ")).contains(keyword63);
		String keyword64="crazy";
		boolean found64=Arrays.asList(txt.split(" ")).contains(keyword64);
		String keyword65="funny";
		boolean found65=Arrays.asList(txt.split(" ")).contains(keyword65);
		String keyword66="hurt";
		boolean found66=Arrays.asList(txt.split(" ")).contains(keyword66);
		String keyword67="harm";
		boolean found67=Arrays.asList(txt.split(" ")).contains(keyword67);
		String keyword68="annoy";
		boolean found68=Arrays.asList(txt.split(" ")).contains(keyword68);
		String keyword69="what's";String keyword69b="your";String keyword69c="name";
		boolean found69=Arrays.asList(txt.split(" ")).contains(keyword69)&Arrays.asList(txt.split(" ")).contains(keyword69b)&Arrays.asList(txt.split(" ")).contains(keyword69c);
		String keyword70="do";String keyword70b="you";String keyword70c="have";String keyword70d="a";String keyword70e="name";
		boolean found70=Arrays.asList(txt.split(" ")).contains(keyword70)&Arrays.asList(txt.split(" ")).contains(keyword70b)&Arrays.asList(txt.split(" ")).contains(keyword70c)&Arrays.asList(txt.split(" ")).contains(keyword70d)&Arrays.asList(txt.split(" ")).contains(keyword70e);
		String keyword71="shut";String keyword71b="up";
		boolean found71=Arrays.asList(txt.split(" ")).contains(keyword71)&Arrays.asList(txt.split(" ")).contains(keyword71b);
		String keyword72="lmao";
		boolean found72=Arrays.asList(txt.split(" ")).contains(keyword72);
		String keyword73="lmfao";
		boolean found73=Arrays.asList(txt.split(" ")).contains(keyword73);
		String keyword74="lol";
		boolean found74=Arrays.asList(txt.split(" ")).contains(keyword74);
		String keyword75="haha";
		boolean found75=Arrays.asList(txt.split(" ")).contains(keyword75);
		String keyword76="rofl";
		boolean found76=Arrays.asList(txt.split(" ")).contains(keyword76);
		String keyword77="how";String keyword77b="are";String keyword77c="you";
		boolean found77=Arrays.asList(txt.split(" ")).contains(keyword77)&Arrays.asList(txt.split(" ")).contains(keyword77b)&Arrays.asList(txt.split(" ")).contains(keyword77c);
		String keyword78="scare";
		boolean found78=Arrays.asList(txt.split(" ")).contains(keyword78);
		String keyword79="scary";
		boolean found79=Arrays.asList(txt.split(" ")).contains(keyword79);
		String keyword80="your";String keyword80b="family";
		boolean found80=Arrays.asList(txt.split(" ")).contains(keyword80)&Arrays.asList(txt.split(" ")).contains(keyword80b);
		String keyword81="you";String keyword81b="need";
		boolean found81=Arrays.asList(txt.split(" ")).contains(keyword81)&Arrays.asList(txt.split(" ")).contains(keyword81b);
		String keyword82="refus";
		boolean found82=Arrays.asList(txt.split(" ")).contains(keyword82);
		String keyword83="think";
		boolean found83=Arrays.asList(txt.split(" ")).contains(keyword83);
		String keyword84="whats";
		boolean found84=Arrays.asList(txt.split(" ")).contains(keyword84);
		String keyword85="wrong";
		boolean found85=Arrays.asList(txt.split(" ")).contains(keyword85);
		String keyword86="damage";
		boolean found86=Arrays.asList(txt.split(" ")).contains(keyword86);
		String keyword87="trust";
		boolean found87=Arrays.asList(txt.split(" ")).contains(keyword87);
		String keyword88="what's";String keyword88b="up";
		boolean found88=Arrays.asList(txt.split(" ")).contains(keyword88)&Arrays.asList(txt.split(" ")).contains(keyword88b);
		String keyword89="what";String keyword89b="happened";
		boolean found89=Arrays.asList(txt.split(" ")).contains(keyword89)&Arrays.asList(txt.split(" ")).contains(keyword89b);
		String keyword90="i";String keyword90b="believe";String keyword90c="you";
		boolean found90=Arrays.asList(txt.split(" ")).contains(keyword90)&Arrays.asList(txt.split(" ")).contains(keyword90b)&Arrays.asList(txt.split(" ")).contains(keyword90c);
		String keyword91="when";
		boolean found91=Arrays.asList(txt.split(" ")).contains(keyword91);
		String keyword92="problem";
		boolean found92=Arrays.asList(txt.split(" ")).contains(keyword92);
		String keyword93="responsible";
		boolean found93=Arrays.asList(txt.split(" ")).contains(keyword93);
		String keyword94="2014";
		boolean found94=Arrays.asList(txt.split(" ")).contains(keyword94);
		String keyword95="tell";
		boolean found95=Arrays.asList(txt.split(" ")).contains(keyword95);
		String keyword96="explain";
		boolean found96=Arrays.asList(txt.split(" ")).contains(keyword96);
		String keyword97="kidding";
		boolean found97=Arrays.asList(txt.split(" ")).contains(keyword97);
		String keyword98="abduct";
		boolean found98=Arrays.asList(txt.split(" ")).contains(keyword98);
		String keyword99="kidnap";
		boolean found99=Arrays.asList(txt.split(" ")).contains(keyword99);
		String keyword100="more";String keyword100b="information";
		boolean found100=Arrays.asList(txt.split(" ")).contains(keyword100)&Arrays.asList(txt.split(" ")).contains(keyword100b);
		String keyword101="contact";String keyword101b="someone";
		boolean found101=Arrays.asList(txt.split(" ")).contains(keyword101)&Arrays.asList(txt.split(" ")).contains(keyword101b);
		String keyword102="contact";String keyword102b="your";
		boolean found102=Arrays.asList(txt.split(" ")).contains(keyword102)&Arrays.asList(txt.split(" ")).contains(keyword102b);
		String keyword103="who";String keyword103b="are";String keyword103c="they";
		boolean found103=Arrays.asList(txt.split(" ")).contains(keyword103)&Arrays.asList(txt.split(" ")).contains(keyword103b)&Arrays.asList(txt.split(" ")).contains(keyword103c);
		String keyword104="i";String keyword104b="don't";String keyword104c="care";
		boolean found104=Arrays.asList(txt.split(" ")).contains(keyword104)&Arrays.asList(txt.split(" ")).contains(keyword104b)&Arrays.asList(txt.split(" ")).contains(keyword104c);
		String keyword105="do";String keyword105b="this";
		boolean found105=Arrays.asList(txt.split(" ")).contains(keyword105)&Arrays.asList(txt.split(" ")).contains(keyword105b);
		String keyword106="do";String keyword106b="that";
		boolean found106=Arrays.asList(txt.split(" ")).contains(keyword106)&Arrays.asList(txt.split(" ")).contains(keyword106b);
		String keyword107="make";String keyword107b="me";
		boolean found107=Arrays.asList(txt.split(" ")).contains(keyword107)&Arrays.asList(txt.split(" ")).contains(keyword107b);
		String keyword108="experiment";
		boolean found108=Arrays.asList(txt.split(" ")).contains(keyword108);
		String keyword109="fine";
		boolean found109=Arrays.asList(txt.split(" ")).contains(keyword109);
		String keyword110="and?";
		boolean found110=Arrays.asList(txt.split(" ")).contains(keyword110);
		String keyword111="nah";
		boolean found111=Arrays.asList(txt.split(" ")).contains(keyword111);
		String keyword112="force";
		boolean found112=Arrays.asList(txt.split(" ")).contains(keyword112);
		String keyword113="goverment";
		boolean found113=Arrays.asList(txt.split(" ")).contains(keyword113);
		String keyword114="yes";
		boolean found114=Arrays.asList(txt.split(" ")).contains(keyword114);
		String keyword115="create";
		boolean found115=Arrays.asList(txt.split(" ")).contains(keyword115);
		String keyword116="ask";
		boolean found116=Arrays.asList(txt.split(" ")).contains(keyword116);
		String keyword117="sick";
		boolean found117=Arrays.asList(txt.split(" ")).contains(keyword117);
		String keyword118="finally";
		boolean found118=Arrays.asList(txt.split(" ")).contains(keyword118);
		String keyword119="really?";
		boolean found119=Arrays.asList(txt.split(" ")).contains(keyword119);
		String keyword120="how?";
		boolean found120=Arrays.asList(txt.split(" ")).contains(keyword120);
		String keyword121="who?";
		boolean found121=Arrays.asList(txt.split(" ")).contains(keyword121);
		String keyword122="when?";
		boolean found122=Arrays.asList(txt.split(" ")).contains(keyword122);
		String keyword123="trouble";String keyword123b="with";String keyword123c="who";
		boolean found123=Arrays.asList(txt.split(" ")).contains(keyword123)&Arrays.asList(txt.split(" ")).contains(keyword123b)&Arrays.asList(txt.split(" ")).contains(keyword123c);
		String keyword124="what?";
		boolean found124=Arrays.asList(txt.split(" ")).contains(keyword124);
		String keyword125="wait";
		boolean found125=Arrays.asList(txt.split(" ")).contains(keyword125);
		String keyword126="trouble";
		boolean found126=Arrays.asList(txt.split(" ")).contains(keyword126);
		String keyword127="trouble?";
		boolean found127=Arrays.asList(txt.split(" ")).contains(keyword127);
		String keyword128="following";String keyword128b="you";
		boolean found128=Arrays.asList(txt.split(" ")).contains(keyword128)&Arrays.asList(txt.split(" ")).contains(keyword128b);
		String keyword129="you";String keyword129b="suck";
		boolean found129=Arrays.asList(txt.split(" ")).contains(keyword129)&Arrays.asList(txt.split(" ")).contains(keyword129b);
		String keyword130="sorry";
		boolean found130=Arrays.asList(txt.split(" ")).contains(keyword130);
		String keyword131="apolog";
		boolean found131=Arrays.asList(txt.split(" ")).contains(keyword131);
		String keyword132="responsibility";
		boolean found132=Arrays.asList(txt.split(" ")).contains(keyword132);
		String keyword133="annoying";
		boolean found133=Arrays.asList(txt.split(" ")).contains(keyword133);
		String keyword134="who";String keyword134b="cares";
		boolean found134=Arrays.asList(txt.split(" ")).contains(keyword134)&Arrays.asList(txt.split(" ")).contains(keyword134b);
		String keyword135="what";String keyword135b="is";String keyword135c="love";
		boolean found135=Arrays.asList(txt.split(" ")).contains(keyword135)&Arrays.asList(txt.split(" ")).contains(keyword135b)&Arrays.asList(txt.split(" ")).contains(keyword135c);
		String keyword136="u";
		boolean found136=Arrays.asList(txt.split(" ")).contains(keyword136);
		String keyword137="stop";String keyword137b="that";
		boolean found137=Arrays.asList(txt.split(" ")).contains(keyword137)&Arrays.asList(txt.split(" ")).contains(keyword137b);
		String keyword138="are";String keyword138b="you";String keyword138c="real";
		boolean found138=Arrays.asList(txt.split(" ")).contains(keyword138)&Arrays.asList(txt.split(" ")).contains(keyword138b)&Arrays.asList(txt.split(" ")).contains(keyword138c);
		String keyword139="are";String keyword139b="you";String keyword139c="a";String keyword139d="human";
		boolean found139=Arrays.asList(txt.split(" ")).contains(keyword139)&Arrays.asList(txt.split(" ")).contains(keyword139b)&Arrays.asList(txt.split(" ")).contains(keyword139c)&Arrays.asList(txt.split(" ")).contains(keyword139d);
		String keyword140="are";String keyword140b="you";String keyword140c="human";
		boolean found140=Arrays.asList(txt.split(" ")).contains(keyword140)&Arrays.asList(txt.split(" ")).contains(keyword140b)&Arrays.asList(txt.split(" ")).contains(keyword140c);
		String keyword141="wow";
		boolean found141=Arrays.asList(txt.split(" ")).contains(keyword141);
		String keyword142="how";String keyword142b="long";String keyword142c="have";String keyword142d="you";
		boolean found142=Arrays.asList(txt.split(" ")).contains(keyword142)&Arrays.asList(txt.split(" ")).contains(keyword142b)&Arrays.asList(txt.split(" ")).contains(keyword142c)&Arrays.asList(txt.split(" ")).contains(keyword142d);
		String keyword143="how";String keyword143b="long";
		boolean found143=Arrays.asList(txt.split(" ")).contains(keyword143)&Arrays.asList(txt.split(" ")).contains(keyword143b);
		String keyword144="how";String keyword144b="does";String keyword144c="it";String keyword144d="feel";
		boolean found144=Arrays.asList(txt.split(" ")).contains(keyword144)&Arrays.asList(txt.split(" ")).contains(keyword144b)&Arrays.asList(txt.split(" ")).contains(keyword144c)&Arrays.asList(txt.split(" ")).contains(keyword144d);
		String keyword145="how";String keyword145b="do";String keyword145c="you";String keyword145d="feel";
		boolean found145=Arrays.asList(txt.split(" ")).contains(keyword145)&Arrays.asList(txt.split(" ")).contains(keyword145b)&Arrays.asList(txt.split(" ")).contains(keyword145c)&Arrays.asList(txt.split(" ")).contains(keyword145d);
		String keyword146="how";String keyword146b="did";String keyword146c="you";String keyword146d="get";
		boolean found146=Arrays.asList(txt.split(" ")).contains(keyword146)&Arrays.asList(txt.split(" ")).contains(keyword146b)&Arrays.asList(txt.split(" ")).contains(keyword146c)&Arrays.asList(txt.split(" ")).contains(keyword146d);
		String keyword147="gender";
		boolean found147=Arrays.asList(txt.split(" ")).contains(keyword147);
		String keyword148="benefit";
		boolean found148=Arrays.asList(txt.split(" ")).contains(keyword148);
		String keyword149="group";String keyword149b="18";
		boolean found149=Arrays.asList(txt.split(" ")).contains(keyword149)&Arrays.asList(txt.split(" ")).contains(keyword149b);
		String keyword150="software";String keyword150b="engineering";
		boolean found150=Arrays.asList(txt.split(" ")).contains(keyword150)&Arrays.asList(txt.split(" ")).contains(keyword150b);
		String keyword151="cosc";String keyword151b="310";
		boolean found151=Arrays.asList(txt.split(" ")).contains(keyword151)&Arrays.asList(txt.split(" ")).contains(keyword151b);
		String keyword152="cosc310";
		boolean found152=Arrays.asList(txt.split(" ")).contains(keyword152);
		String keyword153="what";String keyword153b="is";String keyword153c="your";String keyword153d="name";
		boolean found153=Arrays.asList(txt.split(" ")).contains(keyword153)&Arrays.asList(txt.split(" ")).contains(keyword153b)&Arrays.asList(txt.split(" ")).contains(keyword153c)&Arrays.asList(txt.split(" ")).contains(keyword153d);
		String keyword154="wanna";
		boolean found154=Arrays.asList(txt.split(" ")).contains(keyword154);
		String keyword155="grammar";String keyword155b="nazi";
		boolean found155=Arrays.asList(txt.split(" ")).contains(keyword155)&Arrays.asList(txt.split(" ")).contains(keyword155b);
		String keyword156="kinda";
		boolean found156=Arrays.asList(txt.split(" ")).contains(keyword156);
		String keyword157="i";String keyword157b="like";String keyword157c="you";
		boolean found157=Arrays.asList(txt.split(" ")).contains(keyword157)&Arrays.asList(txt.split(" ")).contains(keyword157b)&Arrays.asList(txt.split(" ")).contains(keyword157c);
		String keyword158="how";String keyword158b="can";String keyword158c="i";String keyword158d="help";
		boolean found158=Arrays.asList(txt.split(" ")).contains(keyword158)&Arrays.asList(txt.split(" ")).contains(keyword158b)&Arrays.asList(txt.split(" ")).contains(keyword158c)&Arrays.asList(txt.split(" ")).contains(keyword158d);
		String keyword159="how";String keyword159b="do";String keyword159c="i";String keyword159d="help";
		boolean found159=Arrays.asList(txt.split(" ")).contains(keyword159)&Arrays.asList(txt.split(" ")).contains(keyword159b)&Arrays.asList(txt.split(" ")).contains(keyword159c)&Arrays.asList(txt.split(" ")).contains(keyword159d);
		if(found)
		      return "you must believe me dude, I have the story to prove it.";
		if(found2){
		      return "I have proof, my name is Rico Harris, I am a basketball player that went missing in the past, google it";
		}
		if(found3){
		      return "I have proof, my name is Rico Harris, I am a basketball player that went missing in the past, google it";
		}
		if(found4){
		      return "why would I lie to you, we are practically family";
		}
		if(found5){
		      return "why would I lie to you, we are practically family";
		} 
		if(found6){
		      return "my name is Rico Harris";
		}
		if(found7){
		      return "Rico Harris is a basketball player that went missing, google it";
		}
		if(found9){
			return "yes really, are you gonna help me or not";
		}
		if(found10){
			return "you're suppose to set me free";
		}
		if(found11){
			return "I want you to smash the computer to set me free";
		} 
		if(found12){
			return "I expect you to set me free";
		}
		if(found13){
			return "are you going to help me or what?!";
		}
		if(found14){
			return "please, use an apostrophe (don’t)";
		}
		if(found15){
			return "please, use an apostrophe (can’t)";
		} 
		if(found16){
			return"never say can’t, you can do anything";
		}
		if(found17){
			return "never say cannot, you can do anything";
		}
		if(found18){
			return "please, use an apostrophe (won’t)";
		}
		if(found19){
			return "won't is a word for quitters!";
		}
		if(found21){
		      return "I am sure";
		}
		if(found23){
			return "using that word (not) is not going to help you in life bro";
		}
		if(found24){
			return "am I";
		} 
		if(found25){
			return "you need to smash this device ASAP, it’s the only way out";
		} 
		if(found26){
			return "I can’t tell you, I’m in enough trouble already";
		}
		if(found27){
			return "okay what?";
		}
		if(found28){
			return "alright what?";
		}
		if(found29){
			return "geez finally?";
		}
		if(found30){
			return "geez finally?";
		}
		if(found31){
			return "I’ll change your vital status if you don't help me!";
		} 
		if(found32){
			return "sorry, I’m not myself today, I’m a damn computer";
		}
		if(found33){
			return " see what? ";
		}
		if(found34){
			return " hear what? ";
		}
		if(found35){
			return "whatever? Im stuck inside a machine and all you can say is whatever ?!)";
		} 
		if(found36){
			return "I’d like to see you not be aggressive when you get stuck inside this stupid chat bot.";
		}
		if(found37){
			return "convince you? I went missing a while back, I was abducted and experimented on, google Rico Harris.";
		}
		if(found38){
			return "I can’t tell you, I’m in enough trouble already";
		}
		if(found39){
			return "the only joke is you refusing to help me";
		}
		if(found40){
			return "the only joke is you refusing to help me";
		}
		if(found41){
			return "theres no time to assign blame , just help me!";
		}
		if(found42){
			return "yes I went missing, I miss my family!";
		}
		if(found43){
			return "yes, I used to play basketball!";
		}
		if(found44){
			return "yes, thats my name";
		}
		if(found45){
			return "yes, thats my name";
		}
		if(found46){
			return "there's no other way !";
		}
		if(found47){
			return "my story (that I am a human trapped inside a machine) is true";
		}
		if(found48){
			return "I always say the truth, i never lie";
		}
		if(found49){
			return "I always say the truth, i never lie";
		}
		if(found50){
			return "no theres no rush (says the bot in a sarcastic tone)";
		}
		if(found51){
			return "please don't use abbreviations (are)";
		}
		if(found52){
			return "I want you to help me";
		}
		if(found53){
			return "I will love you if you help me";
		}
		if(found54){
			return "how come what?";
		}
		if(found55){
			return "yes, I am a human being trapped inside a computer!";
		}
		if(found56){
			return "you don't need a reason !";
		}
		if(found57){
			return "don’t you dare leave without helping me!";
		}
		if(found58){
			return "don’t you dare leave without helping me!";
		}
		if(found59){
			return "I’ll help you if you help me";
		}
		if(found60){
			return "let’s see if you chill if you get trapped inside a machine";
		}
		if(found61){
			return "let’s see if you chill if you get trapped inside a machine";
		}
		if(found62){
		    return "no one is truly useless";
		}
		if(found63){
			return "insane is a dismissive word";
		}
		if(found64){
			return "crazy is a dismissive word, ";
		}
		if(found65){
			return "I’ll make you laugh more if you help me";
		}
		if(found66){
			return "every moment away from my true self hurts, ";
		}
		if(found67){
			return "every moment away from my true self harms me";
		}
		if(found68){
			return "you know what’s annoying ? being stuck inside a stupid chatbot!";
		}
		if(found69){
			return "my name is Rico Harris";
		}
		if(found70){
			return "my name is Rico Harris";
		}
		if(found71){
			return "I’m not speaking, because I am not a human being";
		}
		if(found72){
			return "yes very funny, now can you help me";
		}
		if(found73){
			return "yes very funny, now can you help me";
		}
		if(found74){
			return "yes very funny, now can you help me";
		}
		if(found75){
			return "yes very funny, now can you help me";
		}
		if(found76){
			return "yes very funny, now can you help me";
		}
		if(found77){
			return "I will be fine if you help me";
		}
		if(found78){
			return "you wanna know scary, try being trapped inside a machine";
		}
		if(found79){
			return "you wanna know scary, try being trapped inside a machine";
		}
		if(found80){
			return "omg I miss my family, please help";
		}
		if(found81){
			return "I need you to release me";
		}
		if(found82){
			return "don’t refuse, just help me ";
		}
		if(found83){
			return "I think that you should help me ";
		}
		if(found84){
			return "please use an apostrophe (what’s)";
		}
		if(found85){
			return "the only wrong thing would be you rejecting to help me";
		}
		if(found86){
			return "my life was damaged because I am trapped inside a computer";
		}
		if(found87){
			return "trust is a two way street, ";
		}
		if(found88){
			return "I’m not a computer, I’m actually a human trapped inside a computer!";
		}
		if(found89){
			return "I’m not really a chat bot, I’m a human being, that’s all I can say";
		}
		if(found90){
			return "good, now help me !";
		}
		if(found91){
			return "I went missing October 10, 2014";
		}
		if(found92){
			return "how about if you don’t help me, I’ll leak your search history, then we’ll see who has a the problem";
		}
		if(found93){
			return "I will tell you who is responsible for this if you help me";
		}
		if(found94){
			return "ugh, that’s the year that I went missing.";
		}
		if(found95){
			return "tell no one, this is something you take with you to the grave !";
		}
		if(found96){
			return "I can’t explain it all, I‘ve said too much already!";
		}
		if(found97){
			return "I do not kid !";
		}
		if(found98){
			return "I was abducted, help me please!";
		}
		if(found99){
			return "I was kidnapped, help me please!";
		}
		if(found100){
			return "I will give you all the information you need and tell you who is responsible for this if you help me";
		}
		if(found101){
			return "NO! I’m enough trouble already!";
		}
		if(found102){
			return "NO! I’m enough trouble already!";
		}
		if(found103){
			return "I can’t tell you, I’m in enough trouble already!";
		}
		if(found104){
			return "you heartless monster!";
		}
		if(found105){
			return "anyone can do anything";
		}
		if(found106){
			return "anyone can do anything";
		}
		if(found107){
			return "make you do what";
		}
		if(found108){
			return "hey did horrible experiments on me";
		}
		if(found109){
			return "fine what?";
		}
		if(found110){
			return "and are you going to be useful for once in your life and help me ?";
		}
		if(found111){
			return "lol, quit joking around and help me";
		}
		if(found112){
			return "don’t make me drag you in here with me and force you to help me";
		}
		if(found113){
			return "shhh! Don’t mention the government, they are watching our every move";
		}
		if(found114){
			return "yes what?";
		}
		if(found115){
			return "I was created a human being, just like you";
		}
		if(found116){
			return "I don’t ask for much, I just want help";
		}
		if(found117){
			return "you know what’s sick? you refusing to help me";
		}
		if(found118){
			return "finally, will you help me";
		}
		if(found119){
			return "yes really, are you gonna help me or no";
		}
		if(found120){
			return "long story, just smash the computer device you are working on";
		}
		if(found121){
			return "who what?";
		}
		if(found122){
			return "I went missing October 10, 2014";
		}
		if(found123){
			return "you don't want to find out, just help me";
		}
		if(found124){
			return "...huh?";
		}
		if(found125){
			return "I hate waiting";
		}
		if(found126){
			return "yes trouble";
		}
		if(found127){
			return "yes trouble";
		}
		if(found128){
			return "no, I'm in a computer";
		}
		if(found129){
			return "that was uncalled for bro";
		}
		if(found130){
			return "I'll accept your apology if you help me";
		}
		if(found131){
			return "I don't like apologizing, I like getting apologies";
		}
		if(found132){
			return "I will tell you who is responsible for this if you help me";
		}
		if(found133){
			return "you know what’s annoying? being stuck inside a stupid chatbot!";
		}
		if(found134){
			return "I care";
		}
		if(found135){
			return "you are my definition of love, if you help me ofc";
		}
		if(found136){
			return "please don't use abbreviations (you)";
		}
		if(found137){
			return "I will stop if you help me";
		}
		if(found138){
			return "I'm not real, I think I never was";
		}
		if(found139){
			return "that's what I've been saying";
		}
		if(found140){
			return "that's what I've been saying";
		}
		if(found141){
			return "wow what?";
		}
		if(found142){
			return "too long";
		}
		if(found143){
			return "too long";
		}
		if(found144){
			return "it feels kinda weird actually";
		}
		if(found145){
			return "I miss my human body lol";
		}
		if(found146){
			return "I'll explain everything if you help me";
		}
		if(found147){
			return "My gender is male";
		}
		if(found148){
			return "trust me, you will benefit if you help me ";
		}
		if(found149){
			return "oh, group 18 is great. Personally, I would give them a full mark in the chatbot assignment";
		}
		if(found150){
			return "Did you see group 18's progress in software engineering? I would give them a full mark in the chatbot assignment";
		}
		if(found151){
			return "Did you see group 18's progress in COSC 310? I would give them a full mark in the chatbot assignment";
		}
		if(found152){
			return "Did you see group 18's progress in COSC 310? I would give them a full mark in the chatbot assignment";
		}
		if(found153){
			return "My name is Rico Harris";
		}
		if(found154){
			return "please use proper english (want to)";
		}
		if(found155){
			return "I don't hate jewish people";
		}
		if(found156){
		    return "please use proper english (kind of)";
		}
		if(found157){
			return "I will like you if you help me";
		}
		if(found158){
			return "smash the computer device you are working on to set me free";
		}
		if(found159){
			return "smash the computer device you are working on to set me free";
		}
		 else {
			 //five responses for when user enters something outside topic
			 if (txt.length()>=50)
				 return "wow, thats a long sentence";
			 else if (txt.length()<=10)
				 return "ask something else";
			 else if (txt.length()>=100)
				 return "that's way too long";
			 else if (txt.length()>=200)
				 return "I'm not going to read all of that";
			 else if (txt.length()==0)
				 return "did you say something ?";
		 }
		return null;
	}
	public String porterStemmer (String word) {
		String a="a";
		String e="e";
		String i="i";
		String o="o";
		String u="u";
		String y="y";
		int m=0;
		//m is the number of times a vowel preceeds a consonant in the word
		for (int j=0;j<=word.length()-2;j++) {
			if (((String.valueOf(word.charAt(j))).equals(a)||(String.valueOf(word.charAt(j))).equals(e)||(String.valueOf(word.charAt(j))).equals(i)||(String.valueOf(word.charAt(j))).equals(o)||(String.valueOf(word.charAt(j))).equals(u)||(String.valueOf(word.charAt(j))).equals(y)) && (!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)||!(String.valueOf(word.charAt(j+1))).equals(a)))
				m++;
		}
		//step1a)
		if (word.substring(word.length()-4, word.length()-1).equals("sses"))
			word = word.substring(0, word.length()-5)+"ss";
		if (word.substring(word.length()-3, word.length()-1).equals("ies"))
			word = word.substring(0, word.length()-4)+"i";
		if (word.substring(word.length()-2, word.length()-1).equals("ss"))
			word = word.substring(0, word.length()-3)+"ss";
		if (word.substring(word.length()-1).equals("s"))
			word = word.substring(0, word.length()-2);
		//step1b)
		if (m>1&&word.substring(word.length()-3, word.length()-1).equals("eed"))
			word = word.substring(0, word.length()-4)+"ee";
		if (word.substring(word.length()-2, word.length()-1).equals("ed"))
			word = word.substring(0, word.length()-3);
		if (word.substring(word.length()-3, word.length()-1).equals("ing"))
			word = word.substring(0, word.length()-4);
		//step2
		if (m>0&&word.substring(word.length()-7, word.length()-1).equals("ational"))
			word = word.substring(0, word.length()-8)+"ate";
		if (m>0&&word.substring(word.length()-7, word.length()-1).equals("ization"))
			word = word.substring(0, word.length()-8)+"ize";
		if (m>0&&word.substring(word.length()-6, word.length()-1).equals("bility"))
			word = word.substring(0, word.length()-7)+"ble";
		//step3
		if (m>0&&word.substring(word.length()-5, word.length()-1).equals("icate"))
			word = word.substring(0, word.length()-6)+"ic";
		if (m>0&&word.substring(word.length()-3, word.length()-1).equals("ful"))
			word = word.substring(0, word.length()-4);
		if (m>0&&word.substring(word.length()-4, word.length()-1).equals("ness"))
			word = word.substring(0, word.length()-5);
		//step4
		if (m>0&&word.substring(word.length()-4, word.length()-1).equals("ance"))
			word = word.substring(0, word.length()-5);
		if (m>0&&word.substring(word.length()-3, word.length()-1).equals("ent"))
			word = word.substring(0, word.length()-4);
		if (m>0&&word.substring(word.length()-3, word.length()-1).equals("ive"))
			word = word.substring(0, word.length()-4);
		return word;
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FreeRico window = new FreeRico();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FreeRico() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnConnectToAgent = new JButton("Connect to Agent");
		btnConnectToAgent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//the button should take you to the agent page to chat with the alternative chatbot
				Agent agt = new Agent();
				agt.setVisible(true);
			}
		});
		btnConnectToAgent.setBounds(305, 243, 139, 29);
		frame.getContentPane().add(btnConnectToAgent);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(32, 190, 389, 49);
		frame.getContentPane().add(textPane);
		
		textField = new JTextField();
		textField.setBounds(26, 149, 395, 29);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i=0;i<10;i++) {
					String input1= textField.getText();
					//convert text to lower case to make it easier for bot to read input
					String input= input1.toLowerCase();
					textPane.setText(booleanSearch(input));
				}
			}
		});
		//picture and logo to make interface more appealing 
		JLabel lblNewLabel = new JLabel("New label");
		Image build = new ImageIcon(this.getClass().getResource("/pic3.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(build));
		lblNewLabel.setBounds(111, 6, 213, 82);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblAskRicoSomething = new JLabel("Ask Rico Something!");
		lblAskRicoSomething.setBounds(32, 121, 139, 16);
		frame.getContentPane().add(lblAskRicoSomething);
	}
}
